script.ftvguide
===============

FTV Guide allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther.


This repository is maintained by rayw1986 and bluezed.

For official support go to the forums on http://tvaddons.ag
